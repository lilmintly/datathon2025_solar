"""
Text correction evaluation system package.
""" 