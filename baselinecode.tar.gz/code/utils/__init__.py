"""
Utility functions for text correction evaluation.
""" 