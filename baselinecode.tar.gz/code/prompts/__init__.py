"""
Prompt templates for text correction.
""" 